import java.util.Comparator;
public class TeamFinishedRacesComparator implements Comparator<Team>{
    @Override
    public int compare(Team o1, Team o2) {
        if(o1.numberOfRacesFinished()==o2.numberOfRacesFinished()){
            return o1.getName().compareTo(o2.getName());
        }
        else if(o1.numberOfRacesFinished()>o2.numberOfRacesFinished()){
            return -1;
        }
        else{
            return 1;
        }
    }
}
