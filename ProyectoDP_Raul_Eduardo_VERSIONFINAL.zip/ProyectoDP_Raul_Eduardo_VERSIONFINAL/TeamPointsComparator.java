import java.util.Comparator;
public class TeamPointsComparator implements Comparator<Team>{
    @Override
    public int compare(Team o1, Team o2) {
        if(o1.calculateSumPilotPoints() == o2.calculateSumPilotPoints()){
            return new TeamFinishedRacesComparator().compare(o1, o2);
        }
        else if(o1.calculateSumPilotPoints()>o2.calculateSumPilotPoints()){
            return -1;
        }
        else{
            return 1;
        }
    }
}
